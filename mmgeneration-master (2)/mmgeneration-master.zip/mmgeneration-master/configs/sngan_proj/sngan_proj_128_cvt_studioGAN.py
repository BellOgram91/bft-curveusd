_base_ = ['../_base_/models/sngan_proj/sngan_proj_128x128.py']
