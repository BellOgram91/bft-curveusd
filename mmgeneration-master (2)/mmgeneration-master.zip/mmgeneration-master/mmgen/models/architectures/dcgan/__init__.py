# Copyright (c) OpenMMLab. All rights reserved.
from .generator_discriminator import DCGANDiscriminator, DCGANGenerator

__all__ = ['DCGANGenerator', 'DCGANDiscriminator']
