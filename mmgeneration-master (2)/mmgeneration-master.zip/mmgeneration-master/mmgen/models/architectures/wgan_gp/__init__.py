# Copyright (c) OpenMMLab. All rights reserved.
from .generator_discriminator import WGANGPDiscriminator, WGANGPGenerator

__all__ = ['WGANGPDiscriminator', 'WGANGPGenerator']
