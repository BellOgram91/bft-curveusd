# Copyright (c) OpenMMLab. All rights reserved.
from .generator_discriminator import LSGANDiscriminator, LSGANGenerator

__all__ = ['LSGANDiscriminator', 'LSGANGenerator']
