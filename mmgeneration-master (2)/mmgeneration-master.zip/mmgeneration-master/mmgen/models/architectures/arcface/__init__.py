# Copyright (c) OpenMMLab. All rights reserved.
from .id_loss import IDLossModel

__all__ = ['IDLossModel']
